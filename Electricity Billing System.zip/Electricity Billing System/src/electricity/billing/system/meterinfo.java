package electricity.billing.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class meterinfo extends JFrame implements ActionListener {
    Choice meterlocCho,meterTypCho,phasecodecho,builttypcho;
    JButton submit;
    String meterNumber;
    meterinfo(String meterNumber){
        this.meterNumber=meterNumber;
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(44,217,176,215));
        add(panel);

        JLabel heading=new JLabel("Meter Information");
        heading.setBounds(180,10,200,20);
        heading.setFont(new Font("Tahoma",Font.BOLD,20));
        panel.add(heading);

        JLabel meter_number=new JLabel("Meter Number");
        meter_number.setBounds(50,80,100,20);
        panel.add(meter_number);

        JLabel meterNumberText=new JLabel(meterNumber);
        meterNumberText.setBounds(180,80,150,20);
        panel.add(meterNumberText);

        JLabel meterloc=new JLabel("Meter Number");
        meterloc.setBounds(50,120,100,20);
        panel.add(meterloc);

        meterlocCho=new Choice();
        meterlocCho.add("Outside");
        meterlocCho.add("Inside");
        meterlocCho.setBounds(180,120,150,20);
        panel.add(meterlocCho);

        JLabel meterTyp=new JLabel("Meter Type");
        meterTyp.setBounds(50,160,100,20);
        panel.add(meterTyp);

        meterTypCho=new Choice();
        meterTypCho.add("Electric Meter");
        meterTypCho.add("Solar meter");
        meterTypCho.add("Smart meter");
        meterTypCho.setBounds(180,160,150,20);
        panel.add(meterTypCho);

        JLabel phasecode=new JLabel("Phase Code");
        phasecode.setBounds(50,200,100,20);
        panel.add(phasecode);

        phasecodecho=new Choice();
        phasecodecho.add("011");
        phasecodecho.add("022");
        phasecodecho.add("033");
        phasecodecho.add("044");
        phasecodecho.add("055");
        phasecodecho.add("066");
        phasecodecho.add("077");
        phasecodecho.add("088");
        phasecodecho.add("099");
        phasecodecho.setBounds(180,200,150,20);
        panel.add(phasecodecho);

        JLabel billtyp = new JLabel("Bill Type");
        billtyp.setBounds(50,240,100,20);
        panel.add(billtyp);

        builttypcho=new Choice();
        builttypcho.add("Normal");
        builttypcho.add("Industrial");
        builttypcho.setBounds(180,240,150,20);
        panel.add(builttypcho);

        JLabel day=new JLabel("30 Days Billing Time....");
        day.setBounds(50,280,100,20);
        panel.add(day);

        JLabel note=new JLabel("Note:--");
        note.setBounds(50,320,100,20);
        panel.add(note);

        JLabel note1=new JLabel("By Default Bill is Calculated for 30 Days Only!");
        note1.setBounds(50,340,300,20);
        panel.add(note1);


        submit=new JButton("Submit");
        submit.setBounds(220,390,100,25);
        submit.setBackground(Color.black);
        submit.setForeground(Color.white);
        submit.addActionListener(this);
        panel.add(submit);

        setLayout(new BorderLayout());
        add(panel,"Center");
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icon/details.png"));
        Image i2=i1.getImage().getScaledInstance(230,200,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel imglabel=new JLabel(i3);
        add(imglabel,"East");




        setSize(700,500);
        setLocation(400,200);
        setVisible(true);


    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()==submit){
            String smeterNum=meterNumber;
            String smeterLoc=meterlocCho.getSelectedItem();
            String smetertyp=meterTypCho.getSelectedItem();
            String sphasecode=phasecodecho.getSelectedItem();
            String sbilltyp=builttypcho.getSelectedItem();
            String sday="30";

            String query_meter_info="insert into meter_info values('"+smeterNum+"','"+smeterLoc+"','"+smetertyp+"','"+sphasecode+"','"+sbilltyp+"','"+sday+"')";
            try {
                database c=new database();
                c.statement.executeUpdate(query_meter_info);

                JOptionPane.showMessageDialog(null,"Meter Information Submitted Successfully!");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();

            }
        }else {
            setVisible(false);
        }

    }

    public static void main(String[] args) {
        new meterinfo("");

    }
}
